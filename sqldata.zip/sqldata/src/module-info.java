module sqldata {
	requires java.sql;
}