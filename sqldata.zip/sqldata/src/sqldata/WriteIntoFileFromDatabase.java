package sqldata;

import java.io.*;
import java.sql.*;
import java.util.*;
public class WriteIntoFileFromDatabase {

	public static void main(String[] args) {
		ArrayList<String> data = new ArrayList();

		try {
			Connection con = null;
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://172.19.30.4:3306/titan?autoReconnect=true&useSSL=false", "deepalik", "Hotmail123");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("SELECT cbmm.card_bin,cbm.bank_name,cbmm.scheme_name,cbmm.dom_intl_status,\r\n" + 
					"cbmm.message_type,cbmm.card_type,cbmm.card_variant,cbmm.card_variant_product,cbmm.card_variant_type,cbmm.created_date\r\n" + 
					"FROM card_bin_master cbmm LEFT OUTER JOIN card_bank_master cbm\r\n" + 
					"ON cbmm.bank_master_id = cbm.bank_master_id order by card_bin");

			while (rs.next()) {
				String card_bin = rs.getString("card_bin");
				String bank_name = rs.getString("bank_name");
				String scheme_name = rs.getString("scheme_name");
				String dom_instl_status = rs.getString("dom_intl_status");
				String message_type=rs.getString("message_type");
				String card_type=rs.getString("card_type");
				String card_variant=rs.getString("card_variant");
				String card_variant_product=rs.getString("card_variant_product");
				String card_variant_type=rs.getString("card_variant_type");

				String created_date=rs.getString("created_date");
				
				data.add(card_bin + "|" + bank_name + "|" + scheme_name + "|" + dom_instl_status+"|"+message_type
						+"|"+card_type+"|"+card_variant+"|"+card_variant_product+"|"+card_variant_type+"|"+created_date);

			}
			writeToFile(data, "card_bin_data.txt");
			rs.close();
			st.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private static void writeToFile(ArrayList<String> list, String path) {
		BufferedWriter out = null;
		try {
			File file = new File("C:\\ReadUpdate\\deepalik\\card_bin_data.txt");
			out = new BufferedWriter(new FileWriter(file, true));
			for (String s : list) {
				out.write(s);
				out.newLine();

			}
			out.close();
		} catch (IOException e) {
		}
	}

}
